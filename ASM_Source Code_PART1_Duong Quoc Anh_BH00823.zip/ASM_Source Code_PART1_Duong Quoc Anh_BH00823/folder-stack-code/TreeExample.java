class TreeNode {
    int value;
    TreeNode left, right;

    public TreeNode(int value) {
        this.value = value;
        left = right = null;
    }
}

public class TreeExample {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);  // Root node
        root.left = new TreeNode(2);      // Left child
        root.right = new TreeNode(3);     // Right child
    }
}