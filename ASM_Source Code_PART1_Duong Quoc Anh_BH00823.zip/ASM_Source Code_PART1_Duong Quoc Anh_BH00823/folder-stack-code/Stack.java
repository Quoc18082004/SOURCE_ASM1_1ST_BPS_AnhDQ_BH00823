public class Stack {
    private int maxSize;
    private int[] stackArray;
    private int top;

    public Stack(int size) {
        maxSize = size;
        stackArray = new int[maxSize];
        top = -1;
    }

    public void push(int value) {
        if (top == maxSize - 1) {
            System.out.println("Stack is full. Cannot push " + value);
        } else {
            stackArray[++top] = value;
            System.out.println("Pushed " + value + " onto the stack.");
        }
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
            return -1;
        } else {
            return stackArray[top--];
        }
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Nothing to peek.");
            return -1;
        } else {
            return stackArray[top];
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }

    // Main method to test the Stack class
    public static void main(String[] args) {
        Stack stack = new Stack(3);  // Create a stack with a max size of 3

        stack.push(10);  // Push 10 onto the stack
        stack.push(20);  // Push 20 onto the stack
        stack.push(30);  // Push 30 onto the stack
        stack.push(40);  // Attempt to push 40 onto a full stack

        System.out.println("Peeked at the top element: " + stack.peek());  // Peek at the top element

        System.out.println("Popped: " + stack.pop());  // Pop the top element
        System.out.println("Popped: " + stack.pop());  // Pop the next element
        System.out.println("Popped: " + stack.pop());  // Pop the last element
        System.out.println("Popped: " + stack.pop());  // Attempt to pop from an empty stack
    }
}
