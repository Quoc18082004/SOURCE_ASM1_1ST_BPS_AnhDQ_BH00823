public class ArrayQueue {
    private int[] queue;
    private int front, rear, size;

    public ArrayQueue(int capacity) {
        queue = new int[capacity];
        front = rear = size = 0;
    }

    public void enqueue(int data) {
        if (size == queue.length) {
            System.out.println("Queue is full!");
            return;
        }
        queue[rear] = data;
        rear = (rear + 1) % queue.length;
        size++;
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return -1;
        }
        int data = queue[front];
        front = (front + 1) % queue.length;
        size--;
        return data;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int peek() {
        if (isEmpty()) return -1;
        return queue[front];
    }
}