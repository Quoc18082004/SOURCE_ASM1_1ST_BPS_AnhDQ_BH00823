class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class Stack {
    private Node top;

    public Stack() {
        top = null;
    }

    public void push(int value) {
        Node newNode = new Node(value);
        newNode.next = top;
        top = newNode;
        System.out.println("Pushed " + value + " onto the stack.");
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
            return -1;
        } else {
            int poppedValue = top.data;
            top = top.next;
            System.out.println("Popped " + poppedValue + " from the stack.");
            return poppedValue;
        }
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Nothing to peek.");
            return -1;
        } else {
            return top.data;
        }
    }

    public boolean isEmpty() {
        return top == null;
    }

    // Main method to test the Stack class
    public static void main(String[] args) {
        Stack stack = new Stack();

        stack.push(10);  // Push 10 onto the stack
        stack.push(20);  // Push 20 onto the stack
        stack.push(30);  // Push 30 onto the stack

        System.out.println("Peeked at the top element: " + stack.peek());  // Peek at the top element

        System.out.println("Popped: " + stack.pop());  // Pop the top element
        System.out.println("Popped: " + stack.pop());  // Pop the next element
        System.out.println("Popped: " + stack.pop());  // Pop the last element
        System.out.println("Popped: " + stack.pop());  // Attempt to pop from an empty stack
    }
}
