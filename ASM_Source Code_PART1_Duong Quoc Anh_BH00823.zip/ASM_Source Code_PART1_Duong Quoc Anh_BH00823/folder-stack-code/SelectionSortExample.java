public class SelectionSortExample {
    public static void main(String[] args) {
        int[] scores = {34, 12, 45, 23, 18};
        int comparisons = 0, swaps = 0;

        for (int i = 0; i < scores.length - 1; i++) {
            int minIndex = i;

            // Tìm phần tử nhỏ nhất trong dãy chưa sắp xếp
            for (int j = i + 1; j < scores.length; j++) {
                comparisons++;
                if (scores[j] < scores[minIndex]) {
                    minIndex = j;
                }
            }

            // Hoán đổi nếu cần
            if (minIndex != i) {
                int temp = scores[i];
                scores[i] = scores[minIndex];
                scores[minIndex] = temp;
                swaps++;
            }
        }

        System.out.println("Sorted Array: " + java.util.Arrays.toString(scores));
        System.out.println("Comparisons: " + comparisons + ", Swaps: " + swaps);
    }
}